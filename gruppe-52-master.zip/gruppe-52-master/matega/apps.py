from django.apps import AppConfig


class MategaConfig(AppConfig):
    name = 'matega'
